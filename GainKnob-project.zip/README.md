# Gain Knob

A minimal JUCE audio plugin: one knob, -60 dB to +12 dB, with smoothed gain changes.
Builds as VST3 and Standalone (plus AU on macOS).

## Build

Requires CMake 3.22+ and a C++17 compiler. JUCE is downloaded automatically.

    cmake -B build
    cmake --build build --config Release

Outputs land under `build/GainKnob_artefacts/Release/`:

- `Standalone/Gain Knob` (app you can run right away to test)
- `VST3/Gain Knob.vst3` (copy this into your DAW's VST3 folder)
- `AU/` on macOS

### Linux dependencies (Debian/Ubuntu)

    sudo apt install build-essential cmake pkg-config libasound2-dev libjack-jackd2-dev \
      libfreetype-dev libfontconfig1-dev libx11-dev libxcomposite-dev libxcursor-dev \
      libxext-dev libxinerama-dev libxrandr-dev libxrender-dev libwebkit2gtk-4.1-dev \
      libglu1-mesa-dev mesa-common-dev

## How it works

- `PluginProcessor.cpp`: declares the `gain` parameter (in dB), converts it to a linear
  multiplier, and applies it with a 20 ms smoothing ramp in `processBlock`.
  At -60 dB the output is fully muted.
- `PluginEditor.cpp`: a rotary slider bound to the parameter through
  `AudioProcessorValueTreeState::SliderAttachment`. Double-click resets to 0 dB.
- Parameter state is saved and restored with the DAW session.

## Next steps

Try adding a second parameter (a pan knob or a mute button), or a level meter.
